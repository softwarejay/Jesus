//Jesus Ayala Triva Questions
// this part is asking about games

import java.util.Scanner;



public class Trivia {
	public void myScanner () {
	     Scanner scan = new Scanner(System.in); //Creates a new scanner
	     System.out.println("Who is the mascot of nintendo"); //Asks question
	     String input = scan.nextLine(); //Waits for input
	     if (input.equalsIgnoreCase("Mario")) { //If the input is Mario
	          System.out.println("Correct!");
	     }
	     else { //If the input is anything else
	          System.out.println("Incorrect!");
	          
	          
	public void myScanner () {
	      Scanner scan = new Scanner(System.in); //Creates a new scanner
	      System.out.println("What is the name of marios green buddy"); //Asks question
	      String input = scan.nextLine(); //Waits for input
	      if (input.equalsIgnoreCase("yoshi")) { //If the input is yoshi
	     	          System.out.println("Correct!");
	      }
	     else { //If the input is anything else
	     	          System.out.println("Incorrect!");
	     	     	
	public void myScanner () {
	      Scanner scan = new Scanner(System.in); //Creates a new scanner
	      System.out.println("is princess peach marios sister"); //Asks question
	      String input = scan.nextLine(); //Waits for input
	      if (input.equalsIgnoreCase("no")) { //If the input is no
	     	 	      System.out.println("Correct!");
	     	 	      }
	     else { //If the input is anything else
	     	 	      System.out.println("Incorrect!");	         
	     }
	     
	}

}
