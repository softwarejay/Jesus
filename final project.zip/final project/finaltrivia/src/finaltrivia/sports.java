//Jesus Ayala
//This section will have sports questions
import java.util.Scanner;


public class Trivia {
	public void myScanner () {
	     Scanner scan = new Scanner(System.in); //Creates a new scanner
	     System.out.println("the name of the nfl team in Indianapolis"); //Asks question
	     String input = scan.nextLine(); //Waits for input
	     if (input.equalsIgnoreCase("Colts")) { //If the input is Colts
	          System.out.println("Correct!");
	     }
	     else { //If the input is anything else
	          System.out.println("Incorrect!");
	          
	          
	 public void myScanner () {
	  	  Scanner scan = new Scanner(System.in); //Creates a new scanner
	  	  System.out.println("The Name of the hockey leauge in the usa"); //Asks question
	  	  String input = scan.nextLine(); //Waits for input
	  	  if (input.equalsIgnoreCase("NHl")) { //If the input is NHL
	  	     System.out.println("Correct!");
	  	  }
	  	  else { //If the input is anything else
	  	      System.out.println("Incorrect!");
	  	     }
	  	     	  
	  	     	          	  	    	      	  	     	          	  	    	      
	 public void myScanner () {
	  	  Scanner scan = new Scanner(System.in); //Creates a new scanner
	  	  System.out.println("The Indianapolis cotls QB is Named"); //Asks question
	  	  String input = scan.nextLine(); //Waits for input
	  	  if (input.equalsIgnoreCase("matt ryan")) { //If the input is matt ryan
	  	    	 System.out.println("Correct!");
	  	    	      }
	  	  else { //If the input is anything else
	  	       System.out.println("Incorrect!");  	          
	     }
	}

}
