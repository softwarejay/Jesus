// Jesus Ayala
//this part has Questions about music

import java.util.Scanner;


public class Trivia {
	public void myScanner () {
	     Scanner scan = new Scanner(System.in); //Creates a new scanner
	     System.out.println("who is the king of pop"); //Asks question
	     String input = scan.nextLine(); //Waits for input
	     if (input.equalsIgnoreCase("michael jakson")) { //If the input is michael jackson
	          System.out.println("Correct!");
	     }
	     else { //If the input is anything else
	          System.out.println("Incorrect!");
	          
	          
	public void myScanner () {
	      Scanner scan = new Scanner(System.in); //Creates a new scanner
	      System.out.println("Name the birth place of rapper drake"); //Asks question
	      String input = scan.nextLine(); //Waits for input
	      if (input.equalsIgnoreCase("Toronto")) { //If the input is Toronto
	     	          System.out.println("Correct!");
	      }
	     else { //If the input is anything else
	     	          System.out.println("Incorrect!");
	     	        	
	     	     	
	public void myScanner () {
	      Scanner scan = new Scanner(System.in); //Creates a new scanner
	      System.out.println("did lil nas x make a country son"); //Asks question
	      String input = scan.nextLine(); //Waits for input
	      if (input.equalsIgnoreCase("yes")) { //If the input is yes
	     	 	      System.out.println("Correct!");
	      }
	     else { //If the input is anything else
	     	 	      System.out.println("Incorrect!");    	          
	     }
	}

}
